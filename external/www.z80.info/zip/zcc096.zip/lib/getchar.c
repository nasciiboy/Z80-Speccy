#include <stdio.h>
getchar() {
	return(fgetc(stdin));
}

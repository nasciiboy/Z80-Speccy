	Z80 Emulator 

This is Version 1.0.40 (10:09 AM 3/27/17)  (Changes in file Changes.txt)

  "Intended for hobbyist use only"

This Z80 emulator runs CPM 1.4, CPM 2.2, CPM 3.0, MPM II v2.1 and most software for these systems. 

It will run ISIS 4.x natively, using specially modified BOOT and BIOS PROMs, and an Intellec FDC simulation.

It can run DRI distros of CPM 1.3, CPM 1.4, CPM 2.2 on the sumulated Intellec FDC. 

It can run CPM 1975 (proto CPM) on simulated DS FDC one.

IT will Run Cromemco CDOS and CROMIX on simulated 16FDC with 7 KZ7 64k memory boards. 

It can run some stuff for other emulators and real hardware, using ANSI screen codes and Configurable Terminal Abilities, IO remap, dynamic IO status registers and port capture. 

It will run specially ported software for the Z80 emulator's emulated hardware.(.IMG)

It will run some software for the Z80SIM by Udo Monk.(.DSK) May, now, run networked stuff, too.

It will run TurboDOS 1.43 ported for Z80 Emulator.(networked)

It can read disks from many sources. (Z80SIM, IMD, AltairZ80, etc) Using DC.COM on CPM 22 BIOSdv23/221.

It will run some software "AS-IS" for some combinations of Altair, Imsai, Tarbell, Intellec, SDS and Cromemco systems. (direct memory loads and some bootable disk images .IMG)


Drag-n-Drop Windows to CPM file transfers.

This emulator may still contain bugs! especially in undocumented instruction and 180 and 280 instructions...all 8080 and z80 instructions are believed to be good.

NOTE.. due to a bug in the VB6 Runtime and in Windows Cairo kernel (NT, XP, Vista, and 7), which prevents Visual Basic from working right with network shares, you must make any network shares, used, FULL Control to open files, with the Z80 Emulator. This bug does not apply to Win98. 

CPM 2.2 custom files were developed using the AS8080 package. The CPM 2.2 bios.s, xbios.s, and xbiosins.s are assembled with AS8080(the z80 assembler/disassembler package for Windows 32 bit) There is a version of bios.s (BIOS22.ASM) for CPM 2.2, converted to ASM/MAC format, on one of the disk images. AS8080 is now mainly a DR MAC clone with Intel/TDL Z80 extended mnemonics. 

The system track (trk0) for CPM 2.2, 3.0 and MPM II was created with the Image Builder ,found in a separate download. MOVCPM.COM will create the standard MDS-800 image. ( I always assemble CPM 2.2 BDOS and CCP from source, which is slightly modified to allow AS8080 assemble it, but you should be able to follow the DR instructions to regenerate a different size system or even reassemble, from DRI source, the BDOS and CCP with CPM tools. If you use CPM tools to regenerate CPM2.2, make sure the Serial Numbers Match in MoveCPM and BDOS and CCP) 

The CPM program PutSys.com (writen in HiTech-C) can be used to insert files into various areas of the System tracks, or can copy various parts from another disk.

It is possible to create the system tracks with the DD.EXE program.(However, the included DD.EXE does NOT support long filenames)

The disk images for CPM 1.4 for the Z80 emulator, CPM 1.4 for the Tarbel FDC, and the JadeDD image were created using the DOS program DD.EXE (a rewrite of the GNU dd program) 

Most disks can be created using the DD.EXE, or Disk Image Builder, or PutSys.com

The CPM 1.3 MDS, CPM 1.4 MDS, CPM 1.31 IMSAI,  DS FDCone, and CPM 1975 images were created by Larry Greene.

The xbios62.com was created with Image Builder and then downloaded with dload.com. Can be created with Emulator "Load" and CPM 2.2 "Save xx".("Stop" emulator, Load xbioins62.bin at 100h, xbios62.bin at 300H, "Run" emulator, then SAVE 5 xbios62.com) 

Dropzone.com was created with BDsC running on the emulator.

dload.com and uload.com were created with BDsC running on the emulator. But then ported to be compiled by Hi-Tech-C.

putsys.com, hexdump.com, ls.com, blank.com, and initdirn.com were compiled with HiTech-C on the emulator.

All of custom CPM 3.0 and MPM II custom software was developed running standard CPM programs under this Z80 emulator. COPYSYS.COM for CPM 3 is modified to copy the system track of PC1440, PC4104 and PC8190 disk images(track 0)(actually, any disk with 72SPT on track 0).

CPM 3.0 LDRbios for the banked CPM 3.0 boot disks was built by linking a modified BIOS for CPM 2.2 with a modified CPM3on2 bios. This was "quick and dirty", but since it is only used to load CPM 3.0, it was acceptable.

The bootsector loaders for CPM 2.2 and CPM 3.0 are NOT the same. The Boot Loader for CPM 1.4s (Emulator FDC and Tarbell FDC) are also different as they boot the whole system into memory instead of only the BIOS.

The MPM II bootsector loader is the same as the CPM 3.0 loader.

The MPMLDR xios is a modified version of the CPM 2.2 bios.
The MPM II xios is a custom version derived from both of the sample XIOSs in the DR manuals. 

All custom CPM 3 and MPM II development was done on the emulator running standard CPM programs.
------

This z80 Emulator may or may not come with pre-built disk images. These disk images may be found in a separate downloadable package.(www.z80.info or via cpm.z80.de)


These contain added support for IBM3740 disk images and Z80SIM 4MB/512MB HDs.

(MANY ARE OLDER VERSIONS AND CONTAIN OLDER SOFTWARE. NO ATTEMPT TO KEEP THEM CURRENT)

BOOT62bih.img - Bootable CPM 2.2 (no 512MB HD support)
CalderaCPM3ih.img - Bootable CPM 3.0 banked(5)- Caldera CPM 3.0 binary.
CalderaCPM3ihv33.img - Bootable CPM 3.0 banked(5)- Caldera CPM 3.0 binary.(auto login)
MPMIIv21ih.img - Bootable banked MPM with custom source for XIOS.
CalderaCPM3ihWork.img - Bootable CPM 3.0 banked(5)- Source parts for CPM 3 modular bios. 
CalderaCPM3ihv33Work.img - Bootable CPM 3.0 banked(5)- Source parts for CPM 3 modular bios. (auto login)
CalderaCPM3ihv34Work.img - Bootable CPM 3.0 banked(7)- Source parts for CPM 3 modular bios. (auto login)

BOOT62Bv23.IMG - special BIOS22Dv23, DC.COM, DCI.com, DCJ.com allow disk interchange. THIS IS THE DEFAULT DISK TO USE for CPM 2. It can access 16 drive up to 8mb in size and does auto-login.

BOOT62Bv221.IMG - special BIOS22Dv221. this contains a BIOS that does not do auto-logins.

CalderaCPM3ihv33.img  - special BIOSDv33. THIS IS THE DEFAULT DISK TO USE for CPM 3. It can access 8 drive up to 8mb in size and does auto-login. (plus a 9th drive that is a fixed 512mb drive)

WSSPELL.IMG - Bootable CPM 2.2 system with WordStar4 configured to use CRT and Printer Control Codes.
(NOTE- there seems to be a bug in the WS executable which prevents it from printing Soft-Hyphens.)This disk demonstrates the protential use of the Emulated CRTs and Printers.

These CPM 1.4 disk images are special.  

CPM14.img  -  bios is modified to use Emulators Disk IO.(four 8-Inch IBM3740)
CPM14TB.img - bios is original and uses Emulated Tarbell FDC. (two 8-Inch IBM3740)
CPM13TB.img - original Tarbell CPM 1.3

These CPM 2.2 disk images are special.

JSSSD62.img  - bios JadeDD modified to use Emulated Disk IO (four 8 inch drives)
JSSDD62.img  	Both support IBM3740, Jade Single Sided, Single and Double Density formats. These images do NOT have added support for IBM3740 images or 4MB/512MB HDs.They are availible in a separate download file.

BlankE5.img - A 1440K file containing 1440Kbytes of 0E5h.(a blank disk)

BOOT62b.img - Bootable CPM 2.2 Custom Banked (reloads CCP from an extra bank)

BOOT62nb.img - Bootable CPM 2.2 Non-Banked

CalderaCPM3on2.img - Bootable CPM 2.2(non-banked) with CPM 3.0 loader and CPM 3.0(non-Banked) configured to run on CPM 2.2 bios. After CPM 2.2 boots, run CPMLDR. This configuration uses Bill Smith's CPM3on2 bios, modified to support the emulator's clock. Since the CPMLDR and CPM3.SYS on this disk uses CPM 2.2 bios, it will only boot correctly with CPM 2.2.

CalderaCPM3.img - Bootable CPM 3.0 banked(5)- Caldera CPM 3.0 binary.

BDScWork.img - non-bootable- A usable BDsC with dload.c and uload.c Also, contains RED editor for a Hazeltine 1510.(that's what i have and the Emulator CRT will emulate it)

CPM3Work.img - Bootable CPM 3.0 banked(5)- Source parts for CPM 3 modular bios. PC1440nl.asm does not support drive LOGIN. Only one type of disk is supported(pc1440).

MPMIIv2.img - Bootable banked MPM with custom source for XIOS.

Also available in separate download files are many other images for Z80 Emulator and Z80 Simulator.

These should give you something to experiment with until you figure out how to make you own disks. You can download files into the emulator and make your own disks by using the dload.com program.

System tracks are made with a program (Disk Image Builder in separate package) which places binary files into a disk image file or with DD.EXE. You can also write your own CPM based programs, as described in the DRI documentation, to read and write system tracks, with the emulator. Or use copysys on CalderaCPM3.img...There's also a putsys for Pc1440 images on default disk.

****These disks are provided (without permission) as a convience(since making disks for the emulator is not intuitively obvious) and do not fairly represent the actual complete products. You should download the actual products (cpm.z80.de) and make your own disks from them, and respect the owners rights.

-----
NOTES

Instructions not defined as z80 codes or as undocumented Z80 codes are treated as NOPs. Undefined flags are not set according to real z80. 

64180 instructions are implemented. OTIM(ED 83) and OTDM(ED 8B) affects S, C, P/O and H bits according to result of the decrement of B.(PROBABLY CORRECT)

All I/O instructions affect the N bit according to 180 convention(WRONG FOR Z80 BUT PROBABLY WON'T CAUSE TROUBLE)

z80 emulator treats ED 70 as read port pointed to by C and put value read into flags.(APPEARS CORRECT, some claim it sets psw according to value read, but i am sure it puts value read in PSW.. this allows a co-processor to implement its PSW as an i/o register in the same format as the z80 psw)


All IN/OUT instructions do not use value in B as a component of the port address. (REASONABLE)

H bit is unknown on all I\O instruction that affect it according to data read.(NO IDEA)

The DAA set  Half Carry bit according to the binary result.(MAYBE WRONG) Previous zemu (< 1.0.10)set Sign bit according to BCD decimal results sign which the z80 users guide implies is wrong... now, sets Sign bit according to binary result in A... still not sure if PSW is right after DAA...

The RLD and RRD set PSW according to binary byte result in register. (right according to z80 UG)(prior to 1.0.10 psw result was based on memory)

If the emulator is run on a slow computer(<1000mhz{:-0), it is likely that line editing in the CPM 2.2 Editor(ED) will result in errors which cause the message "Break at..." to be printed. The fix...Don't type Backspaces so fast.

PIP for CPM3 will stall at finish and fail to delete the last temp file, when copying multiple files from one user number to another. Cause and Fix...unknown.

Currently no support for real floppy disk hardware. I know how to access real floppies under NT(assign to device) but not Win9x(assign to Virtual Driver).(dedcided not to implement since floppies are quickly becoming obsolete)

When a HLT or SLP instruction is executed the emulator considers that it is still running.

The lower 7 bits of R register is incremented on M1 

----

The PLM80 and ASM80 for ISX 1.4 are found in the MPM II v2.1 source. To run correctly on CPM, you must have a disk in emulated drive A: and B:

You can boot and run ISIS natively in a 6 drive Intellec simulation.

CPM 2.2 and CPM 3.0 and xbios62 for CPM 2.2 are assembled to use the addresses for TTY, CRT, LPT, SERA and SERB.

MPM II v2.1 is assembled with device 0-7 as console 0-7, and device 8-15 as LPT 0-7

Registry Keys (WIN98se) for Z80 Emulator

My Computer\HKEY_CURRENT_USER\Software\VB and VBA Program Settings\zemu\

Your system may have different keys depending on OS version and User Setup.

It is OK to delete all registry settings for the Z80 Emulator. The next time the emulator is run, it will use all defaults and then create new registry enteries as needed. 

HINT  add a QUALIFIER to the emulators command line in a shortcut to have the emmualtor create separate sets of keys for different configurations... 

\Program Files\zemu\zemu.exe QUALIFIER   (where QUALIFIER is any alpha string..Like ISIS, or CROMEMCO)


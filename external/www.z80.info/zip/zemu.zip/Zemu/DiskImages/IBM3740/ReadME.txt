These CPM 1.4 disk images have custom BIOSes for the Z80 emulator and use USARTs for IO.

you only need to change the Drive properties to IBM3740 to use...

If you want true OLD time fun, download the CPM 1.4 and CPM 1.3 images for the Tarbell FDC

or download the Intellec disk images that contain CPM and ISIS for the Intel MDS-800

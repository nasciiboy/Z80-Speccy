New files are distributed only on Boot62BDv23.img and CalderaCPM3ihv33PC1440.img

The source BIOS on Boot62Dv23 is OLD. I do development of CPM2 BIOSes with AS8080 running on windows.

You can find many older disk images and disk images for other emulators/simulators in separate downloads at The Unofficial CPM web site, and others.

Other PC1440 images may contain old versions of programs.
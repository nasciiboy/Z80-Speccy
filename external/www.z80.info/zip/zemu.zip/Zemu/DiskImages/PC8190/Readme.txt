Boot4104v23.img is a 4MB bootable drive with CPM 2.2 BIOS22v23. 
It contains a valid DD in sector 5, track 0.

CalderaCPM3ihv33PC4104.img is a 4MB bootable drive with CPM 3 ihv33. 
It contains a valid DD in sector 5, track 0.

HiTechC8190v23.img is an 8MB bootable drive with CPM 2.2 BIOS22v23. 
It contains a valid DD in sector 5, track 0.

HiTechC8190ih33.img is an 8MB bootable drive with CPM 3 ihv33. 
It contains a valid DD in sector 5, track 0.

Along with the PC1440 disk images named BOOT62BDv23.img and CalderaCPM3ihv33PC1440.img, you have three different size disks from which to copy the system (CopySys.com) or just the DD (magic) (PutSys.com) to simular drives.

BOOT62BDv23.img is a 1.44MB bootable drive with CPM 2.2 BIOS22v23. 
It contains a valid DD in sector 5, track 0.

CalderaCPM3ihv33PC1440.img is a 1.44MB bootable drive with CPM 3 ihv33. 
It contains a valid DD in sector 5, track 0.


There's a  HiTech C distribution with CPM 2 is on the HiTechC8190v23. It is by default configured to run on drive A:, so stick it in A: and boot. Using Drive A: submit files and C.com work right with standard CPM 2.2's CCP.

There's also a Hi-Tech-C with CPM 3 on HiTechC8190ihv33 disk  (same Hi-Tech-C as the other but with different system tracks, actually works better)

The disk images BOOT62BDv23.img, Boot4104v23.img and HiTechC8190v23.img, contain a DD and BIOSdv23, which does auto-login, but with NO defaults (use DC.COM to mount disk images)

A:-P: default to existing definition (at boot pc1440)

The disk images CalderaCPM3ihv33PC1440.img, CalderaCPM3ihv33PC4104.img and HiTechC8190ihv33.img, contain a DD and CPMLDR.COM and CPM3.SYS with modified BIOSes to auto login the disk drives 

A:-D: default to PC1440
E:-F: default to IBM3740
I:-J: default to Z80SIM 4MB
P: is FIXED

the CPMLDR bios is hacked and ugly...but works to read the CPM.SYS from drive A:...


Bios.s and BootLoader.s
 Original BIOS and BootLoader for the Z80 emulator. 
 This was originally assembled with the original version of AS8080.

TPA3.asm is a program to display location of BIOS, BDOS and CCP in memory.

DPB.asm diplays DPB info for a drive. This version is modified to allow Drive spec as command tail.
  DPB b: ...it now works for both CPM 2 and 3.

CCCP.asm is a program to place a new CCP in the warm boot area of the Banked CPM2.2 Bios.
 You must append the CCP to the binary after assembling or Garbage will be used.
  CCP.COM installs normal DR CCP
  ZCCP.COM installs ZCCP
  ZCPR.COM installs ZCPR1

Hexdump.c is a program to display files in hex, simular to GNU hexdump...
   use HiTech C 

Dropzone.c is the CPM part of the Drag-n-drop windows to Z80EMU interface
  compile with BSDC 

Terminal.asm is a simple terminal emulation program for CPM 2.2 with IObyte supported.
 It won't work with out IObyte support. 
 Example:
  To use z80 Emulator running CPM2 as a simple telNET client.
  Run Xbios62 to install IObyte support on CPM 2.2
  Assign a network device to generic device 14 (serA)
  Run Terminal (to exit type a tilde)
  Set network devices port to 23, specify Server URL then connect.

IDT1440.asm is source for the PC1440 ID table required by BIOS22I. 
(as described in help files, but ommitted from all PC1440 disk images)

DISK2S.asm is source to create test tracks for testing the Z80 Emulator's disk interface.
 64k max size(due to AS8080 max memory constraints)
This is a CPM 3 work disk for creating a CPM3 system. 
This disk is for a CPM 3 system with 9 disk drives. 

The BIOSKRNL.ASM on this disk has been modified to return 
one based sector numbers when there's no Sector Tranlate Table.

This was done to eliminate the translate tables for PC1440 and the HDs.

The DRVTBL.ASM on this disk has been modified to support 9 disks. 
4 PC1440   A:-D:
2 IBM3740  E:-F:
2 4mb HDs  I:-J:
1 512mb HD P:

The PC1440NL.ASM on this disk has been modified to support 9 disks.
And to run with the modified BIOSKRNL.ASM.

BIOSKRNL.ASM and PC1440NL.ASM do not require a sector translation table 
for translating zero based sector numbers to one based sector numbers. 
The translation is done in BIOSKRNL.ASM's sectran routine.

THis is NOT compatible with standard CPM 3 modular BIOS's 
used on other Z80 Emulator disks. 

WARNING the HARDDRIVES (4mb and 512mb)are set up as permanent. 
DO NOT remove (change) while emulator is running CPM 3.
The cached Buffer read data is never flushed. 
The disk is never checked for change. 
V3.1.1 fixes bug in accessing the XDPH...

This is a Caldera CPM 3 work disk for creating a CPM3 system. 
This disk is for a CPM 3 system with 9 disk drives. 

The BIOSKRNL.ASM on this disk has been modified to return 
one based sector numbers when there's no Sector Tranlate Table.

The CPMLDR was modified to allow drive A: to auto-login PCxxxx disks... 
BIOS22f3.asm was modified to do the auto-login.(this means that PCxxxx disk are bootable)

This was done to eliminate the translate tables for PC1440 and the HDs.

The DRVTBL.ASM on this disk has been modified to support 9 disks. 
4 PC1440	  	A:-D: (auto-login for PCxxxx with DD or IDTs)
2 IBM3740  		E:-F: (auto-login for PCxxxx with DD or IDTs)
2 4mb HDs  		I:-J: (auto-login for PCxxxx with DD or IDTs)
1 512mb HD 		P:    (FIXED format, non-removable)

disks A:-D:,E:-F: and I:-J: will auto login PCxxxx disks with either DD or IDT...

A:-D: will default to PC1440 if no IDT or DD is on the disk..
E:-F: will default to IBM3740 if no IDT or DD is on the disk..
I:-J: will default to Z80SIM 4MB if no IDT or DD is on the disk..
P: is a fixed 512MB disk as described for the Z80 SIM 

These defaults make this CPM 3 compatible with the old CPM 3 IH disks.

WARNING - You must use CNTRL-C before and after changing a disk... 
(unless a program is requesting the change and it does Login on select(reset disk). 
Many programs do NOT do login on change of disk, so you may only change a disk 
to one with the same format in this situation)

WARNING - It is easy to get confused and insert a disk with no DD or IDT in a drive that 
defaults to the wrong format... chances are , if this happens, the disk may be corrupted.

DC.COM will NOT run on this system... Use the CPM2.2 BiosDv2.3 for playing with various formats... 

The PC1440.ASM on this disk has been modified to support 9 disks.
And to run with the modified BIOSKRNL.ASM.

The PC1440NL.asm is the old NO LOGIN disk routines.

BIOSKRNL.ASM and PC1440.ASM do not require a sector translation table 
for translating zero based sector numbers to one based sector numbers. 
The translation is done in BIOSKRNL.ASM's sectran routine.

THis is NOT compatible with standard CPM 3 modular BIOS's 
used on other Z80 Emulator disks. 

WARNING the 512 HARDDRIVE (P:) is set up as permanent. 
DO NOT remove (change) while emulator is running CPM 3.
The cached Buffer read data is never flushed. 
The disk is never checked for change. 

rmac bioskrnl
rmac boot
rmac move
rmac chario
rmac drvtbl
rmac pc1440
rmac scb
link bnkbios3[b,q]=bioskrnl,boot,move,chario,drvtbl,pc1440,scb
gencpm

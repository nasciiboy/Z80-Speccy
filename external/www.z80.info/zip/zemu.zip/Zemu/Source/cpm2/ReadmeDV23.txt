The disk image with an "DV23" in the name, contain the CPM 2.2 BIOS22D-v23 that can dynamically reconfigure up to 16 disk drives. (with auto-login)

(NOTE - BIOS22Dv221 and BIOS22Dv22, can dynamically reconfigure up to 16 disk drives (with NO auto-login) (v221 is a fixed BIOS for 8 bit BIOS setsec calls version of v22)

Drives A:-P: can contain up to 8mb disk images.

This BIOS does auto-logins, using either the old IDT(I.D. Table) or a new DD(Disk Definition) located in sector 5, track 0, of each disk, or in separate files. 

The disk BOOT62BDv23.IMG is updated to contain a new bios (BIOS22d-v23)
         
     Bootable 62k Banked Dynamically configurable Version 2.3 of bios
 
Its BIOS22D-V23 has two extra bytes added to the DPBs CPM3 compatibility for programs that use the DPB. This is done for programs that incorrectly do not check what version upon which they are running. 

This BIOS also has a fix for programs that incorrectly do direct BIOS calls using 8 bit sector numbers instead of the required 16 bit sector numbers. Any Disk with a DPB with SPT less than 256 will automatically have the requested sector number in BC truncated to 8 bits. 

Drives A:-P: default to PC1440 disk images (Z80EMU drives default to PC1440, but you can change the default, so make sure that the drive configuration matches the CPM DPB configuration. 

Each drive A:-P: has enough Allocation vector and Checked directory entries to support up to an 8MB disk with 2048 directory entries. Each has an XLT for 256 8 bit sector translation.

The program DC.COM can be used to dynamically change drive parameters.
The program DCC.com can be used to set DPB paramenters for CDOS disk images.
The program DCJ.COM can be used to dynamically LOGIN Jade DD disk images.
The program DROPZONE.COM can be used to bulk transfer files from Windows to the CPM file system.

BIOS22D-v23 does not require an ID Table in sector 5 of a PC1440 disk image. HOWEVER, it can use them. BIOS22d-v23 will auto login any disk with either the old IDT or a new DD. IF Neither IDT or DD is present, Bios22-v23 will leave the current drive configuration AS-IS for both the CPM DPB and the NDI (new disk interface). 

Starting with Z80 Emulator verion 1.0.31 (and up), The DD/IDT can be either in the disk image or in a separate file. If BIOS22v23 is used on older Emulators, there's no external IDT/DDs.

 The DD/IDT is searched for in the following order.

<imagefilename>.IDT,<imagefilename>.DD,Default.IDT,Default.DD and if no files exist, then in sector 5 track 0.

BIOS22v23 will will use an IDT to configure both the CPM DPB and the NDI to a PC1440. (the older BIOS22/I did not confgiure the disk interface, only the DPB)

The DC.COM program injects the PC1440 disk definition info into the DPB and reconfigures the NDI, reguardless of what's in sector 5. But be WARNED, each disk reset (warm boot or Control-c) will cause an auto-login at the next access of any disk currently inserted, if the disk contains(internally or externally) an IDT or DD the auto-login will undo what DC.com may have done.

The DCJ.COM program can configure Jade DD disk images whether or not they contain an IDT is sector 1. The LOGIN function is for disks with a JadeDD IDT (not DD or old Z80Emu IDT) in sector 1(not 5) and no external jade IDTs can be. 
 
All PC1440 disks supplied for the Z80 Emulator do NOT have an old style ID Table in sector 5
BOOT62dv23.img does have a new DD in sector 5. (but it is NOT required) 

Using BIOS22d-v23, any disk with a new DD or an old IDT in sector 5 will be auto logged-in. Both CPM DPB and NDI disk configuration will occur.

Any disk without an IDT or DD will not be auto configured in any way. This is compatible with how the Z80 emulator's old BIOSes used to work.

WARNING  the COPYSYS program will copy all of track 1, including the IDT or the DD if present. may sure that after you transfer the system to a new disk, that you ensure a correct DD or IDT describing the new disk's configuration is in sector 5.(or, if you wish that manual configuration will always be required, sector 5 contains NO magic.) 

DDs for a PC1440, PC4104 and PC8190 are included, along with the old IDT1440.

For DDs and IDTs to work, all that is required of the format, is that sector 5 of track 0 be accessable. IF sector 5 can not be read, no auto-login will occur, however after you make sector 5 accessable, it will.(using BIOS22d-v23)

To use DROPZONE.COM 

Select default User Number for files (drop-down list box, located directly under the DropZone)
Select up to 255 Windows files (no directories) and Drag from Explorer to the DropZone. 
Answer any queries and prompts about invalid or duplicate filenames.
Run CPM program DROPZONE X:    (where X: is a valid CPM drive spec)

Files will be deposited on drive X:

If files are already in the DropZone and you don't want them to be there... run "DROPZONE RESET".
To see what files are in the DropZone ... run "DROPZONE LIST". Files are left in the Zone.

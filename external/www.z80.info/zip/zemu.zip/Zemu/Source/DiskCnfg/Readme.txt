
CnfgDisk.asm, DCI.asm and DCJ.asm are support programs for dynamic disk configuration.
There's two versions, one for BIOS22D and the other for BIOS22v22, BIOSv221, and BIOSv23

BIOS22D allows only drives c: and D: to be re-configured. NO room for HD chk vectors.

  CnfgDisk is DC.COM 
  DC.COM - configures drive properties for some regular disk images.
  DCI.COM - configures drive properties for some IMD disk images.
  DCJ.COM - configures drive properties for Jade DD disk images.

BIOS22Dv22/v221/v23 allow A: thru P: to be reconfigured and has room for Chk vectors on up to 2048 files on an 8 mb drive.

  DCv23.COM - configures drive properties for some regular disk images.
  DCJv22.COM - configures drive properties for Jade DD disk images.
  DCIv22.COM - configures drive properties for some IMD disk images. (this is depricated by DCC and DCE)
  DCCv23.COM - configures drive properties for some CDOS disk image (normal and IMD)
  DCEv1.COM - configures drive properties for some Epson disk images (normal and IMD).

WARNING - Some systems, such as CDOS and TPM put entries on the disk that are not standard CPM meta data. When encountered by CPM, CPM usually uses the DM fields to mark allocated blocks. Since the DM fields in these non-standard entries are not DM info, some blocks may get marked as allocated that are not actually used... This can also happen when running CPM 2 with CPM 3 disks that the directory has been formatted for Date/Time Stamps...bottom line..CPM 2 reports more space used than is actually used...


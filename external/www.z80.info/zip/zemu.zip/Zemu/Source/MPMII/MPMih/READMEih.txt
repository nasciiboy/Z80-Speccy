This disk is a work disk for creating a banked MPM 2.1 system disk
The bnkxios.spr is created from modified resxios.asm and diskio.asm

This MPM system has 9 disk drives defined

A:-D: PC1440
E:-F: IBM3740
I:-J: 4mb Hard drive (z80sim compatible)
P:    512mb Hard drive (z80sim compatible)

WARNING - Hard drives are not checked for media change

DO NOT SWAP HDs without a DSKRESET


Dropzone.c is the CPM part of the Drag-n-drop windows to Z80EMU interface
  compile with BDSC 

WARNING-Text files created by windows that are exactly MOD 128 get transferred with no CNTRL-Z at the end.

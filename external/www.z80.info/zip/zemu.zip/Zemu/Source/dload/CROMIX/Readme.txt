the libraries for CROMIX are NOT original. They are derived from but NOT the same.

The AS8080 assembler does not support all the directives, so many definitions are not used the same as the originals would be.
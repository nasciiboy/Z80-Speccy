Most of the Assembler sources were written to either be assembled by DR-ASM, DR-MAC, or AS8080 (separate download)

CPM 2.2 was used to bootstrap the Z80 Emulator.
The Z80 Emulator's CPM2 system sources was written for AS8080 (original version)

After CPM 2.2 was up-and-running on the z80 emulator...
The CPM3 and MPM system stuff was assembled using the DR-Products recommended in instructions.
The CPM1 system stuff was done with AS8080, simply because it was easier than trying to use CPM 2.2.

since the original bootstrapping...AS8080 has been re-written to be very DR-MAC compatible.

Most System Assembler sources are to be assembled with DR-MAC or DR-ASM.

Most utilities are to be assembled with AS8080. 

AS8080 allows larger symbol names and several features NOT in DR-ASM or DR-MAC.
Minor changes may be required to assemble with DR.

Most C source are to be compiled with HiTech C.

Some C sources are to be compiled with BDSC.

Most Pascal sources are Turbo-pascal 3.0

The CROMIX stuff was assembled using AS8080, because the Cromemco Assembler's disassembled source will not assemble correctly. And i do not have the original Cromemco assembler. (v3)

Without the Cromemco assembler and linker, i can only produce non-relocatable COM files for CROMIX.
Luckily, COM files can make either CROMIX OS calls or CDOS OS calls.
#include <cpm.h>
#include <stddef.h>

#include "B:BDOSSTRU.H"

char SetDMA (char * pDMA)
{
/*	ptrDMA=pDMA; */
	return(bdos(CPMSDMA,pDMA));
}
char SetUSER (int pUser)
{
	if (pUser>=0 && pUser <=15)
	{
	 bdos(CPMSUID,pUser);
	 return(0);
	}
	else
	 return(255);
}
char GetUSER ()
{
	return(bdos(CPMSUID,255));
}
short GetCPMVERS ()
{
	return(bdoshl(CPMVERS));
}
char Seldsk (int pDrive)
{
	if (pDrive>=0 && pDrive <=15)
	{
	 bdos(CPMLGIN,pDrive);
	 return(0);
	}
	else
	 return(255);
}
char GetCURDISK ()
{
	return(bdos(CPMIDRV,0));
}
char FindFirst(struct CPMfcb * pFCB)
{
	return (bdos(CPMFFST,pFCB));
}
char FindNext(struct CPMfcb * pFCB)
{
	return (bdos(CPMFNXT,pFCB));
}
struct CPMdpb * GetDPB()
{
	return ((struct CPMdpb *)bdoshl(31,0));
}
uchar * GetALV()
{
	return ((uchar *)bdoshl(27,0));
}
long GetFSP (int pDrive, char * pDMA)
{
int RTN;
	RTN=bdos(46,pDrive);
	if (RTN!=0)return(-1);
	pDMA[3]=0;
	return ( *(long *)pDMA);
}
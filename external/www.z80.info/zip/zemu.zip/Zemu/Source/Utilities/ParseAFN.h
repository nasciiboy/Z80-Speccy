void PrintFCB(struct CPMfcb * pFCB, int pFull);
void InitFCB(struct CPMfcb * pFCB, char pChar);
int ParseFN (struct CPMfcb* pFCB, char * pFilename, int pUFN);
	/* 1 no filename, 2 null name, 3 null ext, 4 FN.EX both null */
	/* -1 filename too long, -2 ext too long, -3 ch invalid name, -4 ch invalid ext */
	/* -5 too many * in FN, - 6 too many * in EXT  */
int ParseDRU (struct CPMfcb* pFCB, char * pFilename);
	/* -1 DefUSR,-2 BadUsr,-3 Bad Disk */

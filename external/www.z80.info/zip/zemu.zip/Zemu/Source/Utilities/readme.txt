LS is a LS kind-of-clone for CPM 2.2...it works on CPM 3 but some things are displayed "not perfectly"

InitDirN is a new Initdir program for CPM 3... unlike the original InitDir, it only works on blank disks... 
  the real Initdir fails to work on disks with more than 59 sectors per track.

Blank is a program that writes 0xE5 to the entire Data Area of a disk... it does NOT write to the System Area...Nor does it write beyond the Data Area.. It writes 0xE5s to each block in the data area. 

As such, Blank does not erase the entire disk, it wipes only all files on the disk.. the disk remains bootable (if it was) and any other logical disks in the image file are unaffected..(only if DPB is correct)

Both Blank and InitDirN will run on both CPM 2 and CPM 3, using biosx.as routines.

The file biosx.as contains routines for Hi-tech-C which allows a more versatile access to the Bios on CPM 2 and CPM 3..All registers start in a Bios Parameter Block; and, after the BIOS call, the Bios Parameter Block is updated with the register contents.. This allows the passing of a value in any register to BIOS and the acquisistion of the contents of any register after the BIOS call. 

PutSys runs on CPM 2 and CPM 3. It is used to extract and write various System parts to the System tracks of a PCxxxx disk image. The part written can be extracted from an existing disk or from a CPM file. 

(These are all compiled with Hi-Tech-C running on CPM 3, using HiTechC8190ihv33.img in A: and a work disk in B:)
WARNING--this is under development..but mostly works now

if you have SDOS please send a copy to me.(not on original disks, i dont have disk drives to read) 

InRomSdm.hex - original SD Monitor from SBC200/JadeDD/serial
InRomVF2.hex -original SDOS BIOS for VersafloppyII with VFDiag from SBC200/VersafloppyII/VDB(flashwriter)

NOTE - the SDM from the InRomSdm.hex is NOT compatible with the VDiag in InRomVF2.hex. The disk IO routines (SDOS BIOS) still work properly, But the address linkage between VFDiag and SDM is wrong. The file F000VF2.hex contains a fixed version of the VF2's diagnostic linkage.

Here's the drive select codes for SDM's read and write drive command

SIZE	8	8	5	5	8	8	5	5
SIDES	1	2	1	2	1	2	1	2
DENSITY	S	S	S	S	D	D	D	D

A	00	10	20	30	40	50	60	70
B	01	11	21	31	41	51	61	71
C	02	12	22	32	42	52	62	72
D	03	13	23	33	43	53	63	73

to run on z80 emulator

New IO map file (SBC200VF2XR2.iom) will do most of the work for you. It will set the right IO Map and set the right CPU.

MUST load IOmap SBC200VF2XR2.iom (SBC200 IO, VerasaFloppyII IO, ExpandoramII bank select)

load memory InRomVF2.hex (loads at 0xF000) or F000vf2.hex (fixed linkage)
load memory InRomSdm.hex (loads at 0xE000) 

goto 0xE000

NOTES


the simulated VF2 uses a simulated WD17xx(the same used for Tarbel and Cromemco 16FDC).. the Simulated WD17xx does NOT support ReadTrack command 

the simulated VF2 seems to work fine with these roms... 

i dont know the disk formats for the VersafloppyII, SDOS, they may all have single density track 0 or not. But based on the VFdiag code, it appear that they all have homogenous sector size and density,
which means, the double density and 256 byte, 8 inch formats are NOT standard IBM Diskette 2D formats.. only one and two sided single density 8 inchers are IBM standard.

the SDOS BIOS assumes that double sided disks simply extend the track on side 0 with extra sectors on side 1. Side IDM fields on both sides contain Side ORed with 80 for two sided disks... 

Track 4 would consist of both sides of cylinder 4, sectors on track 4 would be 1-18 on side 0 then sectors 19-36 on side 1.(NOTE - sector IDs are 1-18 on both side 0 and side 1...a WD17xx can work with sector IDs 19-36 on a track, but not the z80 emulator, so good thing they did not think of it)

(normally, for many other systems, track 4 would be cylinder 2, side 0, sectors 1-18; with track 5 as cylinder 2 side 1, sectors 1-18)

The Emulator's Disk Formats for IBMs use hetrogenous sector and densities for 1,2, and 2D IBM formats(if needed) 


the emulated WD17xx does the following, which i believe should be sufficent to detect the type of drive..

read, and read track address of wrong density fails...density of track is stored in the emu's drive properties. requested density is set via command register at 0x63 (dens) (rnf)

read, and read track address of wrong clock type fails...clock type of track is stored in the emu's drive properties. requested clock type is set via command register at 0x63  (8/5)(rnf)

read, and read track address of side that does not exist fails.(rnf)
IDM flag indicates that the emulator must return side ORed with 0x80(as is expected by VF2ROMS)

read, and read track address of cyl or trk beyond end of disk fails.(rnf)

with these, you should be able to detect density, number of cylinders, and if two sided.

The emulator does NOT issue error message boxes for step and seek errors..
Also does not report error in the case where software reads status and then does not issue command if NOT ready.
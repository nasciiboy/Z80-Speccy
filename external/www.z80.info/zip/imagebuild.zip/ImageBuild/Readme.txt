The is Version 2.0.4 (12:51 PM 8/22/14)of Disk Image Builder.

Disk Image builder is for Building CPM 2 Disk Images. While it also has several nice support features, the main purpose is to build Images, not edit disks. (it is not designed to build CPM 3 disk images with DTS)

USE OF CPM 3 DISKS WITH DTS TURNED ON, is AT YOUR OWN RISK

Image Builder supports raw access to the System tracks and data tracks of various Z80 Emulator Disk Images.

Version 2 now supports Drag-n-Drop file tranfers from windows explorer to CPM filesystems on Z80 Disk Images. 

Formats supported are IBM3740, PC-1440, PC-4104, PC-8190 and 6 Jade DD image formats. These are the basic Images that the Z80 Emulator was designed to use. While the Z80 Emulator also supports many other Disk Image formats, Disk Image Builder is restricted to these.

The Z80 Emulator also supports Drag-n-Drop windows to CPM file transfers, so using the Z80 Emulator, you can transfer to any Disk Image Format that the Z80 Emulator can access. 

About disk images...

IBM3740 is the standard distribution media for CPM on 8 inch disks. 

PC-1440 is a native 3.5 inch format designed to be used in a JADE DD system with the 8 inch drives replaced with 3.5 inch drives. As such it has features that the Z80 emulator does not need or use. When used on a real JadeDD system, there's a DCM(in 9-16) which the Z80 Emulator does not use. Instead the Z80 emulator uses a BOOT sector (in 6), that the JadeDD does NOT use. The PC1440 format also has an IDT (I.D.Table in 5) which can also be called the DD (Disk Definition). The real JadeDD requires an IDT that the BIOS uses to Identify the disk type, and set the CPM DPB parameters. The Z80 emulator, has several versions of BIOS. Some totally ignore the IDT/DD. Others, use the IDT/DD similarly to the JAdeDD. There's 2 formats of IDT/DD. The IDT (magic="3.5 1440") format is for PC1440 disk images only. The DD (magic="NDI-Z80E")format can be used for many types of disk images, but is mainly for the disk images specifically for the Z80 Emulator. 

PC-4104 is a fictitious 4 MB format specifically for the Z80 Emulator. It can contain a DD, which can be used to auto login the disk image.

PC-8190 is a fictitious 8 MB format specifically for the Z80 Emulator. It can contain a DD, which can be used to auto login the disk image.

The 6 Jade formats are the standard formats used by the Jade DD disk controller, and with slight modification for use on the Z80 emulator. Like the PC-1440 format, there's parts used by the JadeDD and other parts used by the Emulator. When used on a real JadeDD system, there's a DCM(in 13-20) which the Z80 Emulator does not use. Instead the Z80 emulator uses a BOOT sector (in 3), that the JadeDD does NOT use. The Jade formats also have an IDT (I.D.Table in 1, magic="Jade DD ").(some Jade software was released with the magic in all caps, so some Jade systems only look for the "J")

The JadeDD formats when used on the Z80 Emulator, have a modified BIOS specifically for the Z80 emulator, that does not support the DCM. This allows the Jade disk images with modified BIOS and added BOOT sector to be booted on the Z80 Emulator, and appear to function similarly as they would on the real JadeDD.

The Z80 Emulator can boot run any OS that has been ported to the Z80 Emulators special simulated hardware. 

Some real hardware that the Z80 Emulator supports is...

Tarbel Single and Double Density disk controllers, using a WD17xx FDC.

SD Systems Versafloppy II, using WD17xx FDC.

Intellec FDC/MDS800 FDC 

IMSAI FIF

Cromemco FDC16/64, using WD17xx FDC, and 7 Cromemco KZ-64s.

The Z80 Emulator also has special fictious hardware.

The Z80SIM Simulator's special hardware (minus network device)
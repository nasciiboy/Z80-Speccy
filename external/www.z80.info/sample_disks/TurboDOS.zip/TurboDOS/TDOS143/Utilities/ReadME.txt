This Distro of TurboDOS 1.43 is made up from the TurboDOS files in the MASLIN archives, plus files provided by Larry Greene. Some source for drivers from...

  Version 1.41 implemented by Per Frejvall for simh/AltairZ80 computer.  Credit to Peter Schorn.
  Upgraded to 1.43 by Larry Greene.
  Network and Console drivers for 1.30 by Mario Viara.
  Modified to run on Z80 Emulator(2015-3-23)

Included utilities are:

AUTOLOAD.COM	
BANK.COM    	
BATCH.COM   
BOOT.COM    	
BUFFERS.COM 	
 CF.COM      	
CHANGE.COM  	
CHECKDIR.COM
COPY.COM    	
date.com(y2kfixed)
DATEorg.COM    	
 DEL.COM
DELETE.COM  	
dir.com(y2kfixed)
DIRorg.COM     	
DO.COM      
DRIVE.COM   	
DUMP.COM    	
ERASEDIR.COM	
 ERASEFIL.COM
FIFO.COM    	
FIXDIR.COM  
FIXMAP.COM  	
GEN.COM     	
LABEL.COM   	
LOGOFF.COM  	
LOGON.COM   
MASTER.COM  	
 MONITOR.COM
*PACKAGE.COM 	
PRINT.COM   	
PRINTER.COM 	
 PRLTOCOM.COM
QUEUE.COM   	
RECEIVE.COM 	
RELCVT.COM  	
 RELTOA.COM  
RENAME.COM  	
SEND.COM    	
SET.COM     	
SHOW.COM  
 TERMINAL.COM  	
TYPE.COM    
 WHO.COM     

DEL.COM and DELETE.COM appear to be the same file.

The indented files appear to be added to distro.

The * files are added, but from Software 2000.

NO FORMAT.COM or BACKUP.COM

21#1118.SER


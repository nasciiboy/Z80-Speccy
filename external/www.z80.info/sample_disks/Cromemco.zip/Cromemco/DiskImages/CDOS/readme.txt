the file CDOS217.IMD is a 5 inch disk (SMSSSD)...use with 5 inch system

you must load a disk format for CDOS5.DSk (SMDSDD) and CDOS8.DSK (LGDSDD)

CDOS will auto detect the type of disk and properly set up it's internal DPBs, but the physical disk format must be set maually or by an IMD file. (emulator v 1.0.37 and up supports all IMD file features.)

WARNING the emulator may not do what you expect, if you switch between IMD and NON-IMD disk images... especially in auto login situations... systems that auto login usually read a sector (sect 1 trk 0) to find out what type of disk you have inserted... the extra IMD data in an IMD image causes the emulator to read the wrong data of a non-IMD image... 

so, make sure you always load the correct disk format for non-IMD images... the IMD image file contain the info required for configuring them... and the emulator will use that info when an IMD disk image is opened... 

for IMD images, the disk configuration is fairly automatic..

but for NON-IMD images , you MUST load the correct disk format...

(the emulator does NOT create IMD images... it always creates non-IMD images...)




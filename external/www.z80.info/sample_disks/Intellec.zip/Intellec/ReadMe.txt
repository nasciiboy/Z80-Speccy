To Boot ISIS or CPM for the MDS-800....

ISIS originally ran on a real Intel Development system. That system, Like an IBM PC, used a ROM based BIOS, which isolated some hardware specifics. 

The PROM set consisted of two PROMs, an initialization/diagnostic/boot PROM located at 0xE800 and a BIOS/MONitor PROM located at 0xF800.

The E800/boot PROM got switched out after it performed its functions(initialization and booting). The F800/BIOS PROM must remain, because ISIS and CPM relies on that BIOS. 

The original PROMs are for an Intel Intellec Series II development system. The original PROMs will NOT run on the Z80 Emulator. ( It would require simulating the entire Series II and neither ISIS nor CPM use most of that hardware. )

Replacement PROMs are provided which are specifically modified to run on the Z80 Emulator.(F8_v2.hex and E8_V2.hex)

The Z80 Emulator supports two Intel FDCs. Each can be configured as a SD FDC or a DD FDC.

The DD FDC only supports Double Density disks. The SD FDC only supports Single Density disks.

The default configuration has FDC0 as a DD and FDC1 as an SD. 

The following drive configuration is for a two FDC system with FDC0 a Double density controller and FDC1 a Single density controller

The IO remap file Intellec2.iom remaps FDC0 to 0x78 and FDC1 to 0x88. Intellec1.iom places only FDC0 mapped to 0x78. 

USing the Intellec2.iom configuration,  drives A:-D: are on the DD FDC0 and E:-F: are on the SD FDC1

The allowable configurations for ISIS are 

one SD FDC at 0x78 (SD)

two SD FDC at 0x78 and 0x88 (SD + SD)

one DD FDC at 0x78 (DD)

one DD at 0x78 and one SD FDC at 0x88 (DD + SD)

ISIS will automatically detect these configurations.

CPM does not dynamically detect how the FDCs are configured. 
The SD CPM 2.2 disk image uses SD + SD and the DD CPM 2.2 disk image uses the DD + SD configuration.

To boot... for a two FDC system with FDC0 DD and FDC1 SD (DD + SD), you must...

Load Intellec2.iom (this maps FDC0 to 0x78 and FDC1 to 0x88)
It also maps the CRT and TTY and LPT and maps some dummy locations that ISIS and CPM requires.

Load F8_V2.hex (the Init/boot PROM)

Load E8_v2.hex (the BIOS)

GOTO 0xE800 (or optionally set Reset Execution address to 0xE800 and push reset button)

Using Drive PRoperties, load ISISssDD.fmt for drives A:-D: and ISISssSD.fmt for E:-F:

Insert a Bootable Double Density ISIS disk image (or the special CPM DD image)

Follow on screen instructions..
Should say "space bar to activate" on both DEV0 and DEV1
Then menu to select Boot ISIS, or CPM, or Monitor..

(HINT-ISIS treats TTY and CRT differently... best to set DEV0 to a TTY and DEV1 to a CRT)

Select I to boot ISIS. (or C for CPM)

Should see a prompt "-" (or A: for CPM)

Have fun!

To boot original DRI CPM for the MDS-800 (or single density ISIS)

The Double Density CPM above is NOT the original DRI CPM relaese.

The original DRI CPM for the MDS-800 used a two FDC system with two Single Density FDCs (SD + SD).

So instead of setting A:-B: as ISISssDD.fmt , set A:-B: to ISISssSD.fmt

You must also change the default FDC0 to be SINGLE density instead of Double density.

Drives on the second SD FDC1 will be at E: and F: (unless you change defaults)

Instead of DD disk image, use SD image..

Otherwise the same as above.

Have Fun!


Hints for using ISIS with PROMS...

There are two interrupts that ISIS and the Mon80/BIOS PROM expect. Each is initiated either by executing a RST1 or RST0 instruction; or by pressing front panel buttons..

RST 0 is the software abort button for Mon80. (also breakpoint)

RST 1 is the Restart ISIS button.

Use the Debug Console's command RST X to simulate push button 0 and 1

so, when ISIS gets stuck... do a debug console RST 1 
  RST1 (or go 8) causes ISIS to close all files and restart..

when debugging and stuck use RST 0 
	this will appear as a breakpoint and control goes to MON80. ( RST0 )

note - RST 0 handler in MON80 expects a return address on the stack. RST 1 handler in ISIS does not, so Go 8 also works.


You can also re-program the NMI push button to respond with either vector =0 or vector = 8, if you MUST have a button to push.

(Warning - ISIS checks to see if user defined IO is implemented... CPM does not.. For CPM, do not attempt to do IO to user defined IOBYTE devices before using the IODEF call to install drivers.)


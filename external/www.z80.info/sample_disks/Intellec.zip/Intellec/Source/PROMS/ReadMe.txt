These are a modified BIOS PROM (F800) and a new BOOT PROM (E800) fixed to run on the Z80 Emulator

They are assembled with AS8080

Version 2.1

added code to CSTS to fakeout ISIS such that it sees RDY to NRDY transitions...this makes "paste as input" and CRT key definitions work properly... used byte at 0x3c as toggle flag...





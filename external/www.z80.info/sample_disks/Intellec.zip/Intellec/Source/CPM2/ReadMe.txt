These are BIOSes for both Single Density only and a Double Density + Single Density Intellec system

They are assembled with AS8080

The single density system is almost the same as the DRI distribution CPM bios for the MDS-800. Only minor changes to facilitate entry point of the Mon80 Restart was made, and removed test for boot switches.

The single density BIOS supports 4 drives, 2 on an SD FDC0 at 0x78 and 2 on an SD FDC1 at 0x88

The double density system is modified to use the Z80 Emulator's implementation of the Intellec Series II DD FDC + MDS-800 SD FDC... it might work on a real system.

The Double density BIOS supports 6 drives.. 4 on the DD FDC0 at 0x78 and 2 on the SD FDC1 at 0x88

The disk format used for SD images is the standard IBM3740 format used by many

The disk format used for DD images is a manifestation in that "it is not known if it was ever used by anyone"

DD disk format..

77 tracks... all tracks are 52 SPT 128 BPS (including track 0..the DD FDC does not support SD at all)

for CPM 1 track reservered. Track 0 contains CPM in sectors 1-52 and is formatted as though Track 0 was 2 tracks.. (1-26) + (27-52)  CPM is loaded from Track 0. 

differences between SD image and DD image...

the cold start loader in sector 1 loads CPM from two tracks for SD and from one track DD.
the BIOS supports 4 drives for SD and 6 drives for DD.
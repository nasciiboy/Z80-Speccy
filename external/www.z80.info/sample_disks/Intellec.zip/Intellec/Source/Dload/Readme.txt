DLOADb is the bootstrap DLOAD program... it was writen as the first iteration of DLOAD... then it was used to download a newer more advanced version of DLOAD

DLOAD is usable in that it will download a file to an ISIS disk and ask to overwrite if the file exists, and give some user feedback......DLOADb just does it reguardless... 

you will find both DLOAD and DLOADb on the ISISv41dd.img disk image. From here the universe awaits..


ULOAD is used to up load files to the host

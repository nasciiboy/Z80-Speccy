Intellec1.iom supports only one FDC0 at 0x78
Intellec2.iom supports  FDC0 at 0x78 and FDC1 at 0x88

both support ULOAD and DLOAD ports at their default addresses 0xA0-0xA3

DROPZONE's ports conflict with the location of the FDC at 0x88

DROPZONE will need to be recompiled for CPM (using different ports than normal) and rewriten for ISIS...

watch for updates of the Intellec disk image package.
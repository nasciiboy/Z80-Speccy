MOst of these disks are from Udo Monk's website unix4fun.org/z80pack, and are for Uod's Z80SIM simulator.  They are provided here simply as a convienence to those who dont know how to use TAR and TGZ compressed archives... some are created from files found on the CPM softare archives. 

To boot on the ZEMU Z80 Emulator, you need to select I/O ports for Z80SIM. You must also select disk type IBM3740. 

To read or write with Z80Emulator based O.S.s (PC1440 disks), you must use drives e and f and again select IBM3740 disk type. Use only O.S.s supporting IBM3740 type disks such as those with an "ih" in the name, or the Jade DD disks.




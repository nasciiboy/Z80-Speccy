these are the Original IMSAI OEM unmodified bioses  for IMSAI CPM 1.31; and, were typed from the IMSAI CPM 1.31 Alteration Guide by Udo Munk 

Larry Greene (larrygr510@gmail.com) used them to make a slightly modified BIOS used to make a relocatable CPM system for (MOVE)CPM.COM (the unmodified bios is contained here...the changes were to allow a special DRI program to create the (move)CPM.COM image, and should correctly represent the unmodified originals here.... i am saying that you should use the originals , here , to make your modified BIOS)

the CPM.COM contains the OEM IMSAI BIOS. When you do a new system (with CPM.COM) the new system contains this OEM IMSAI BIOS and NOT the original MDS bios... so, if you want to use the IMSAI OEM BIOS, then it is already included in your NEW system. if you subsequently do a new IMSAI BIOS, you MUST follow the patch prcedure described in the CPM 1.3 Alteration Guide.

INFO...some CPM distributors, distributed the (move)CPM.COM with the original MDS800 BIOS.  Some also used a special DRI program to replace the MDS800 bios (in moveCPM.COM) with their own OEM bios. What ever BIOS is in the CPM.COM image is included when you make a new system.. if you want another BIOS (customized by you), then you need to use the patch procedure described in the Alteration Guide.

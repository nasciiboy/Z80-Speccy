this CPM 1975 img was provided by Larry Greene(larrygr510@gmail.com)

it was compiled from CPM 1975 source , with the PLM crosscompiler.. 

it contains a modified boot loader, because original was missing..



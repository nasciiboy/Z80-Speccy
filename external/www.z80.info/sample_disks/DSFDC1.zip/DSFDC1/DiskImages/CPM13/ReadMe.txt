CPM13.img was provided by Larry Greene(larrygr510@gmail.com),who got the components to build it from Jeff Shook

it was compiled from CPM 1.3 source , with the PLM crosscompiler.. 

it contains a modified boot loader that does not use DSFDCONEs auto boot and system reset features. 

CPMb13.img contains an original boot loader, that works with the DSFDCONEs auto boot feature..



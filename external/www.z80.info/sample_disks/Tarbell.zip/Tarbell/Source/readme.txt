This is a CPM 1.4 system scrounged from parts, but mainly from the CPM14-b.zip file..

The BIOS is written using only 8080 instructions.

The BIOS is the original that was in the cpm14-b.zip file.
The BOOTLDR is the original that was in the cpm14b.zip file
Both use the Tarbell FDC emulated device.

I made NO changes to the original BIOS and Boot Loader.

This disk also contains the IMSAI 9k Basic assembled for CPM, with cassete. 
(don't forget to type NEW, else program and or data corruption can occur)
(YOU MUST TYPE "NEW" BEFORE DOING ANYTHING WITH IMSAI 9K BASIC)

This BASIC 9K is modified to match the source in the manual, but has a bug fix applied
(Thanks to Larry Greene for fixing the bug)

This CPM 1.4 supports only IBM3740 disks.
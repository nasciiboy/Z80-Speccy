#!/bin/sh
# copy the default SevenuP.ini file to  the apps resources
# This is run as a post-build step on OS X
cp "/Volumes/Users/Users/james/Documents/Code/SevenuP-v1.10-src-WIP Folder/SevenuP.ini" "/Volumes/Users/Users/james/Documents/Code/SevenuP-v1.10-src-WIP Folder/build/SevenuP.app/Contents/Resources/"

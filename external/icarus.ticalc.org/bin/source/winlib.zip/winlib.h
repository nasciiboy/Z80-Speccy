;����������������������������������������������������������������������������
;                       WINDOW LIBRARY FOR USGARD
;                        (C) 1997 by Andreas Ess
;
;Use this library to have damn cool windows. WINLIB is fulfilled with features
;This library is a MUST!
;
;This version is written for Usgard 1.1, you need to include this file before
;the .end statement in your program.
;
;Then, before you can use WINLIB, call &WIN_INIT, after usage, call &WIN_EXIT.
;To call a window function, use WIN_CALLER:
;
;call &WIN_CALLER \ .db WIN_PSHOW
;
;ATTENTION: if you modify the memory using VAR_RESIZE / VAR_DELETE, you have to
;perform a WIN_EXIT first, after the operation, WIN_INIT again!!!!
;
;NOTE:
; ...that (WIN_DEST_ADDR) specifies where the Window is drawn.
; ...that I removed WIN_COPY. If you need it, mail me.
;
;REQUIREMENTS:
;the last 30 bytes of the DelC buffer
;����������������������������������������������������������������������������

;NAME:          WIN_PREPARE
;INPUT:         B,C upper left corner of window(X/8)
;               H,L size(X/8)
;               DE  pointer to title
;               IX  pointer to contents
;               A   status byte:
;                       bit 0:  draw title?
;                       bit 1:  draw contents?
;                       bit 2:  'de-actualize' old window?
;OUTPUT:        registers destroyed, window table (inside library) prepared
;FUNCTION:      use this before fWIN_SHOW to prepare the window
WIN_PREPARE = 0

;NAME:          WIN_SHOW
;INPUT:         none
;OUTPUT:        all registers destroyed
;FUNCTION:      this draws the window according to the window table
WIN_SHOW = 1

;NAME:          WIN_CLEAR
;INPUT:         none
;OUTPUT:        registers destroyed
;FUNCTION:      clear contents field of window(like CLEARLCD)
WIN_CLEAR = 2

;NAME:          WIN_ERROR
;INPUT:         IX -> pointer to error text, bit 3 of USG_BITS set if direct exit
;OUTPUT:        registers destroyed
;FUNCTION:      displays error window and exits if set 3, (USG_BITS)
WIN_ERROR = 3

;NAME:          WIN_CHOICE
;INPUT:         B = maximum number of choices - 1, win table set
;OUTPUT:        registers destroyed, A = D = choice number
;FUNCTION:      displays a choice window and lets the user select an option, APD!
WIN_CHOICE = 4

;NAME:          WIN_PSHOW
;INPUT:         same as WIN_PREPARE
;OUTPUT:                -"-
;FUNCTION:      prepare window and show it afterwards
WIN_PSHOW = 5

;NAME:          WIN_INVERT
;INPUT:         C = row to highlight(relative to window start)(0 = first row)
;OUTPUT:        HL modified
;FUNCTION:      inverts row C
WIN_INVERT = 6

;NAME:          WIN_CHC_EX
;INPUT:         same as WIN_CHOICE + HL = pointer to function to be called
;               in keyloop. The input for your function is:
;               INPUT:  D = absolute choice
;                       C = relative choice
;                       if you modify A, you modify the keypress!
;OUTPUT:        same as WIN_CHOICE
;FUNCTION:      in addition to WIN_CHOICE, a function gets called inside the
;               keyloop.
WIN_CHC_EX = 7

;CONTROL CHARACTERS FOR CONTENTS
LF = 255        ;Linefeed
TAB = 254       ;Normal tabulator(X & $F0 + 16)
NUM = 253       ;show next word as unsigned number
STAB1 = 252     ;Set 1st tab to actual position
STAB2 = 251     ;Set 2nd tab
GTAB1 = 250     ;Go to 1st tab
GTAB2 = 249     ;Go to 2nd tab
XTAB = 248      ;go (next byte) pixels to the right
BNUM = 247      ;display next byte as unsigned number
YTAB = 246      ;go (next byte) pixels down
LINE = 245      ;draw horizontal line ("hyphen")

;WINDOW DATA:
;WIN_DATA        = TEMP_STORAGE+87
WIN_DATA        = TEMP_STORAGE+87
WIN_POS         = WIN_DATA      ;Y position, X pos / 8
WIN_POSY        = WIN_DATA
WIN_POSX        = WIN_DATA+1
WIN_SIZE        = WIN_DATA+2    ;Y size, X size / 8
WIN_HGT         = WIN_DATA+2
WIN_WDT         = WIN_DATA+3
WIN_SCRLPOS     = WIN_DATA+4    ;Y scrolling position, X not supported(only graph)
WIN_SCRLY       = WIN_DATA+4
WIN_ADDR        = WIN_DATA+6    ;(Y*16)+X+VIDEO_MEM
WIN_TITLE       = WIN_DATA+8    ;pointer to title string
WIN_CONT        = WIN_DATA+10   ;pointer to contents
WIN_STAT        = WIN_DATA+12   ;Status byte:   bit 0:  draw title?
				;               bit 1:  draw contents?
				;               bit 2:  deactualize old win?
				;               bit 6:  draw left border?
				;               bit 7:  draw right border?
WIN_TEXTX       = WIN_DATA+13   ;text X starting position inside window
WIN_TEXTY       = WIN_DATA+14   ;text Y starting position
WIN_REGION      = WIN_DATA+15   ;(Y*16)+X+VIDEO_MEM+128 (the window drawing reg.)
WIN_RSIZE       = WIN_DATA+17   ;size of the drawing region
WIN_TAB1        = WIN_DATA+19   ;TAB 1 position
WIN_TAB2        = WIN_DATA+20   ;TAB 2 position
WIN_LINE        = WIN_DATA+21   ;number of lines which fit into window
WIN_FUNC        = WIN_DATA+22   ;function being called during WIN_CHOICE loop
WIN_DEST_ADDR   = WIN_DATA+24   ;destination of window drawing
WINL_ADDR       = WIN_DATA+26
SAVE_HL         = WIN_DATA+28
WIN_OUTPUT      = WIN_DATA+30   ;output type: 0 = DEC / 1 = HEX

WIN_INIT:
	ld      HL, (WIN_ADDR)
	ld      A, L
	or      H
	ret     nz

	ld      HL, &WinName
	call    RELOC
	jr      c, WinErrorMessage
	inc     HL
	ld      (WINL_ADDR), HL
	ld      HL, VIDEO_MEM
	ld      (WIN_DEST_ADDR), HL

;        ld      HL, WIN_DATA
;        ld      BC, 29
;        call    OTH_CLEAR
	ret
WinErrorMessage:
	call    CLEARLCD
	ld      ($800C), DE
	ld      HL, &WinName
	call    D_ZT_STR
	call    D_ZT_STR
	call    OTH_PAUSE
	ret

WIN_EXIT:
	ld      HL, (WIN_ADDR)
	ld      A, L
	or      H
	ret     z

	ld      HL, &WinName
	call    DERELOC
	ld      HL, 0
	ld      (WIN_ADDR), HL
	ret

WIN_CALLER:
	ld      (SAVE_HL), HL
	ld      HL, (WINL_ADDR)
	push    HL
	ld      HL, (SAVE_HL)
	ret

WinName: .db "winlib",0
Req: .db " required!",0

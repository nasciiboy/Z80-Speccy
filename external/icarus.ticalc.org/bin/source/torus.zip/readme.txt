

                            3 D    R O U T I N E S

                              23rd November 1998

                              by Matthew Shepcar
                              Icarus Productions
                             

    About the Routines --------------------------------------------------

    I originally wrote these routines for Descent/86.  However, I doubt
    that Descent/86 will ever be completed and I feel that these routines
    may be of use to other TI-8x programmers.  They're fairly simple and
    shouldn't be too difficult to build on and to use in your own code.


    Included Routines ---------------------------------------------------

    line.asm - A very fast straight line drawing routine (uses Bresenham
               algorithm).

    3Drot.asm - Routines for rotating a point in 3 dimensions

    trigtab.asm - Sine/cosine lookup tables

    mult.asm - Fast multiplication routines


    Using the Routines --------------------------------------------------

    Included is an example of how to use the routine to display a 3D
    rotating wireframe torus on the screen.   Reading this should help
    to clarify some of the descriptions of the routines below:

    == trigtab.asm ==

    In order to make use of the trig tables you must first build them to
    a free area of memory.  To keep programs small only 64 values are
    stored in trigtab.asm itself.  To build the rest of the table you
    must make a call to BuildTrigTables which will copy 320 values to
    SinCosTable which is a variable you must define yourself.

    Values in the table range from -127 to 127.  360 degrees corresponds
    to 256 entries in SinCosTable.   The values in the table are actually
    the sines of the angles.  To calculate the cosine of an angle you
    should add 64 to the angle and then look it up as a sine.

    Examples:  To find sin(A) and place the value in A,

      ld hl,SinCosTable
      ld e,a
      ld d,0
      add hl,de   ;hl=SinCosTable+A
      ld a,(hl)

    To find cos(A) the first line can simply be replaced with:

      ld hl,SinCosTable+64


    == line.asm ==

    The line routine is pretty straightforward.  You simply put the
    coordinates in hl and de such that the line goes from (H,L)-(D,E).

    Example:  To draw a line from (20,10)-(100,50):

      ld hl,20*256+10  ;h=20, l=10
      ld de,100*256+50 ;h=100, l=50
      call Line


    == 3Drot.asm ==

    The rotation routines are slightly more complex to use.   In practice,
    when you are rotating a 3D object you are likely to rotate a large
    number of points in the same way.  To make this run more quickly a
    3D rotation matrix should be calculated beforehand and then applied
    to each point in turn.   The routine for calculating this matrix is
    CalcTransformationMatrix.   You supply the three angles in A, B and C
    before calling this and it builds a rotation matrix to memory.

    Once you have calculated the matrix you can apply it to each point.
    You load the X, Y and Z coordinates into A, B and C respectively and
    then call RotatePoint to achieve this.   The rotated points are
    returned in HL, DE and BC.   You are likely to then want to project
    these points by multiplying both X and Y by a constant and dividing
    by Z.   Code to achieve this can be found in torus.asm immediately
    after the call to RotatePoint.

    Example:   Setup a rotation matrix and rotate a point,

      ld a,30
      ld b,60
      ld c,90
      call CalcTransformationMatrix
      ...
      ld a,(hl)
      inc hl
      ld b,(hl)
      inc hl
      ld c,(hl)          ;read point from memory at HL
      inc hl
      push hl
      call RotatePoint
      ...


    == mult.asm ==

    The multiplication routines are required by 3Drot.asm but you may find
    them useful especially in a 3D application.   They are very easy to
    use and an explanation of how to use them can be found in mult.asm
    itself.


    Contact Information -------------------------------------------------

    Icarus productions:
      http://icarus.ganymed.org/

    Matthew Shepcar:
      pmysmps@nott.ac.uk

    I hope you find these routines useful.  If you have any queries about
    them please feel free to email me.

    ---------------------------------------------------------------------

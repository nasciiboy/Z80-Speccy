***************************************************************************

		English Help for GBA asm library
			Translated by James Lennon 7-20-08

***************************************************************************


Finally an english version of the tutorial has been translated. I did it because I can't read french very well and I wanted to know how to use this library and so I translated it. Now others can use it more easily. For the most part it should be sensible to read, but there are some places where it is difficult due to unfamiliar wording and the stupid online translator messed it up (even after I fixed it in english).
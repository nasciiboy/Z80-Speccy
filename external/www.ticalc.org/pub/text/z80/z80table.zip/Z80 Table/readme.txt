=============Z80 TABLES=============

There are 7 tables in this HTML file, which contain all Assembly instructions and their respective opcodes.

There are both official and unofficial and unofficial instructions, correctly labeled. 

There may be one or two errors in the table, but I'm sure that later updates will fix these.

This table can be found online at www.davidgom.co.cc/z80table.html.

Also, making this table was very hard work and it shall not be released without David Gomes's authorization. Thanks.


Table compiled by:
> Collin Anderson;
> David Gomes;
> Zachary Wassall.

Thanks to: Omnimaga Community (www.omnimaga.org)

Uploaded, converted to HTML and hosted by: David Gomes	
Project.........Zeda's Hex Codes
Program.........Zeda's Hex Codes
Author..........Zeda Elnara (ThunderBolt)
E-mail..........xedaelnara@gmail.com
Size............N/A
Language........English
Programming.....N/A
Version.........1.32
Last Update.....3:26 PM 3/12/2012

Suggested Font	Any fixed width font (like Courier New)
Suggested Size	11

*Do NOT view with Word Wrap
*The following should fit on one line:
================================================================
Notes
================================================================
  This is a quick reference to over 60 hexadecimal opcodes for
BASIC programmers. This includes all of the standard ones, plus
a few not-so standard codes. How about converting a string to a
program, or making your keys repeat super fast? It's pretty fun
stuff if you ask me :P
================================================================
History
================================================================
3:28 PM 3/12/2012-v1.32 added a few more screen shifting codes.
18:06 03/09/2011-v1.31 further optimises some of the key press
codes and I added in another lowercase key press lock thing.
10:23 27/02/2011-v1.21 fixed "run indicator off" because I
accidentallly put another opcode that was EF0745
20:56 23/02/2011-v1.20 added a few more codes and the "Programs"
section.
23:55 26/01/2011-v1.10 ready for TICalc upload :)
================================================================
Project.........Zeda's Opcode Reference
Program.........N/A
Author..........Zeda Elnara (ThunderBolt)
E-mail..........xedaelnara@gmail.com
Size............N/A
Language........English
Programming.....N/A
Version.........1.00.Beta
Last Update.....17:38 19/01/2011

Suggested Font	Any fixed width font (like Courier New)
Suggested Size	11

*Do NOT view with Word Wrap
*The following should fit on one line:
================================================================
Who's it for?
================================================================
  This is designed for anybody who needs quick access to how
Z80 commands work. It provides the hex for each mnemonic as well
and for some things there is more info provided (sticky notes,
kind of). That part is still not finished, but I like the idea
enough that I want to finish it sometime.
================================================================
How To Use
================================================================
Just open the document and look for a command. For example, if
you see ld hl,**, you will see that it is in the row "2" and
column "1" meaning the hex is 21****. To see how it works, look
to the right of the chart for LD.

Some instructions are extended (like CB and ED) so the extended
instructions are displayed below the chart.
================================================================
Notes
================================================================
If you hover over the codes in the top row, some info will be
displayed about the opcode. I plan to do this for all of the
codes, but I am kind of busy for the time being.
================================================================
History
================================================================
17:45 19/01/2011-Getting ready for the first release!
================================================================
// dummy file (needed to compile with MFC)

// zxdeb needs CPP compilation
//#define CPP_COMPILATION
  

SnapList v1.00
==============
Copyright 2002 Chris Cowley. <ccowley@grok.co.uk>

A free, open-source, SNA to ASCII BASIC listing utility.

It's GPL. Read the file gpl.txt if you don't understand what
this means!


Usage
-----
Type "snaplist snapshotname.sna >outputfile.txt"

Excluding the ">outputfile.txt" parameter will cause the output to
be written to the console.


Details
-------
Snaplist extracts the Sinclair BASIC program listing from any
.sna format snapshot.

The escape codes used for graphics characters are compatible with
Russell Marks' zmakebas utility (which converts in the other
direction; an ASCII BASIC listing to a Spectrum .TAP file)


Files
-----
snaplist.c      The ANSI C source code. It currently relies on 
                intel byte ordering, so be aware of this if you
                are porting it to another platform.
gpl.txt         The GNU General Public Licence.
snaplist.exe    32-bit Windows Executable (command-line).
snaplist        Linux ELF binary (for Pentium-based systems)
readme.txt      This text file.
QuoteRight for Windows 95/98, Windows NT, or Windows 2000
=========================================================
Copyright �2000 Grok Developments Ltd.

Version 1.12

QuoteRight.EXE turns a clipboard full of material into quoted lines with a
return character (<CRLF>) pair at the end of each. You can specify the desired
line length, and the quote character to use.

The original idea for QuoteRight came from Andy Mabbett after a discussion in 
the newsgroup 'demon.service' regarding the relative merits of various news
clients. See http://www.deja.com/viewthread.xp?AN=581247968 for the history.

Visit http://freestuff.grok.co.uk/ for other free things!

IMPORTANT NOTES:-
QuoteRight comes with ABSOLUTELY NO WARRANTY.

QuoteRight is freeware - you can do whatever you want with it as long as you:-

  1) Don't modify either the QuoteRight.EXE file or this readme.txt file.

  2) Ensure this readme.txt file is included whenever you distribute
     QuoteRight.EXE.

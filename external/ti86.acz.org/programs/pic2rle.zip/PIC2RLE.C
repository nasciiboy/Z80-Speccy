/**************************************************************************\
| PIC2RLE v1.5 -- Title screen compressor                                  |
|                                                                          |
| David Phillips <electrum@tfs.net>                                        |
| started:     08/19/98                                                    |
| last update: 01/06/99                                                    |
|                                                                          |
| The format for RLE encoded pictures is simple.  Single bytes are encoded |
| as themselves.  Runs of 3 or more bytes are encoded as $91, followed by  |
| the byte value, ended with the number of bytes.  The single value of $91 |
| is encoded as a run of one.  The maximum length of a run is 255, because |
| runs are encoded as a single byte.  This is very close to PCX encoding.  |
\**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//======== GLOBAL VARIABLES ===============================================
char pic[1024];

//======== FUNCTIONS ======================================================
void read_pic(char *fname)
{
  FILE *fp;
  char header[62],
       buffer[1024];
  int  x, y;

  fp = fopen(fname, "rb");
  if (fp == NULL)
  {
    printf("Cannon open file %s -- make sure it is in\n", fname);
    printf("the same directory (folder) that you ran PIC2RLE from.\n");
    exit(1);
  }
  else
  {
    fread(&header, sizeof(header), 1, fp);
      
    fread(&buffer, 1024, 1, fp);
    
    fclose(fp);
    if (errno != 0)
    {
      printf("Error reading %s -- file is corrupt!\n", fname);
      exit(1);
    }
    for(y = 0; y < 64; y++)     // bitmap files go bottom to top
      for(x = 0; x < 16; x++)
        pic[(y * 16) + x] = buffer[((63 - y) * 16) + x];
    for(x = 0; x < 1024; x++)   // bitmap files are reversed
      pic[x] = 255 - pic[x];
  }
}

void rle_pic(char *fname)
{
  FILE *fp;
  int  x,
       size,
       run;
  char last;
  
  fp = fopen(fname, "w");
  if (fp == NULL)
  {
    printf("\nError opening %s.  PIC not written!\n", fname);
    exit(1);
  }
  
  fprintf(fp, "; compressed picture made with PIC2RLE\n");
  fprintf(fp, "; PIC2RLE by David Phillips <david@acz.org>\n\n");
  
  size = 0;
  run = 1;
  last = pic[0];
  for(x = 1; x < 1025; x++)
  {
    if ((x != 1024) && (pic[x] == last) && (run < 255))   // will early out
      run++;
    else
    {
      if ((run > 2) || (last == 0x91))
      {
        fput_num(fp, 0x91);
        fput_num(fp, last); 
        fput_num(fp, run);
        size += 3;
      }
      else
      {
        fput_num(fp, last);
        size++;
        if (run == 2)
        {
          fput_num(fp, last);
          size++;
        }
      }
      if (x != 1024)
      {
        run = 1;
        last = pic[x];
      }
    }
  }
  
  x = (int)(((float)size / 1024) * 100);
  fprintf(fp, "\n\n; 1024 bytes compressed to %i", size);
  fprintf(fp, " -- %i\%% of original.\n", x);
  fclose(fp);
  printf("RLE PIC was written as %s.\n", fname);
  printf("1024 bytes compressed to %i -- %i\%% of original.\n", size, x);
}

void fput_num(FILE *fp, char value)
{
  static num = 0;

  if (num % 12 == 0)
    fprintf(fp, "\n .db $%02x", value);
  else
      fprintf(fp, ",$%02x", value);
  num++;
}

//======== MAIN() =========================================================
void main(int argc, char *argv[])
{
  printf("\nPIC2RLE -- by David Phillips <david@acz.org>\n\n");
  
  if (argc == 1)
  {
    printf("Usage:  PIC2RLE <bmpfile> [outfile]\n\n");
    printf("  Bmpfile is a 128x64 monochrome bitmap file (1-bit) to\n");
    printf("  be compressed using RLE compression.  If outfile isn't\n");
    printf("  specified, compressed picture is written to PIC_OUT.ASM.\n");
    exit(1);
  }
  
  read_pic(argv[1]);
  
  if (argc == 2)
    rle_pic("pic_out.asm");
  else
      rle_pic(argv[2]);
}

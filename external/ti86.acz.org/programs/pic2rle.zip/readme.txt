===========================================
= PIC2RLE v1.5 -- Title screen compressor =
= Z80 assembler code for the TI-86        =
= by David Phillips <david@acz.org>       =
= Release date: 08/19/98                  =
= Last update:  01/06/99                  =
===========================================

Description:

This is a RLE (run-length-encoding) compressor/displayer for the TI-86.
The compressor, PIC2RLE is written in C for the PC.  It should compile
under any DOS 16 or 32-bit compiler  The decoder, RLE.ASM, is a 32-byte
decoder written in Z80 assembler for the TI-86, but it should work for
any TI-8x calculator (except the TI-89, because it doesn't have a Z80!).

Note: 

The run indicator byte changed from version 1.0, so you need to recompress
any pictures if you want to use the new decompressor with them!

Usage:

Create a 128x64 monochrome (1-bit) bitmap.  Windows Paint works well, and
is an easy way to create a cool looking title screen.  Make sure you save
it as monochrome and that the dimensions are 128x64, as no checking is done
on the input file!

PIC2RLE mypic.bmp smallpic.asm

The first argument is the bitmap file, and the second is the file where the
compressed picture is to be written.  If the target file is not specified,
pic_out.asm will be used by default.

Either include the compressed picture in your program with the #include
directive, or cut and paste in there.  To display the picture in your
assembler program, you need to CALL the decompressor, which is named
DispRLE.  When you call it, HL should point to the compressed picture to be
displayed, and DE points to where it should be displayed to.  You will
normally want to display it to video memory, which is at $FC00.  See the
included program, PICDISP.ASM, for an example on this.

Notes:

I wrote this in one day as a response to all the newbies on assembly-86
asking how to compress title pictures, and because I could not find a
suitable program myself.  There are a few programs that would work, but I
feel they are too much trouble for a simple title picture:

Lite86 -- Kirk Meyer
Bloat -- Matthew Shepcar (SCaBBy)
Huffman compression (came with Sqrxz) -- Jimmy Mardell

The program used to require you to convert your picture to an asm file,
compile it and turn it into a .86p file first.  These extra steps are no
longer required, as it now reads bitmap files directly.  I must thank Trent
Lillehaugen for sending me the source to bmp2asm.  This helped me
tremendously in learning how to read in bitmap files.

Files:

README.TXT  -- The file you are reading right now
PIC2RLE.EXE -- The compressor for the PC
PIC2RLE.C   -- C source for the PC compressor
RLE.ASM     -- Z80 32-byte displayer/decompressor
PICDISP.ASM -- Example program for displaying pictures
PICTURE.BMP -- Demo bitmap picture
PIC_RLE.ASM -- Demo compressed picture

Versions:

08/19/98:  1.0 -- First version and public release
11/05/98:  1.1 -- Changed run indicator byte because I realized that $80 is
                  not a good choice.  $91 seems to work out much better.  I
                  fixed the compressor to not record runs of two as
                  individual bytes, because a run takes up three  bytes,
                  thus taking up more space than leaving them as individual
                  bytes.  A long time ago, CLEM pointed out a 3 byte
                  optimization to my decompressor that I finally got around
                  to adding, which brings the size from 35 bytes down to 32
                  bytes.
01/06/99:  1.5 -- Thanks to Trent Lillehaugen, I changed it to read in bitmap
                  files directly.  This should save everyone some steps.


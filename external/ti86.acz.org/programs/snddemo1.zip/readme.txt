Sound Demo 0.9
	
	- Matt Johnson

This simple program uses the link port to output sound. You will need a 2.5mm <--> 3.5mm
adapter. This can be purchased at Radio Shack. Simply run the program, plug in the 
headphones, and enjoy! 

The source code will be included at a later date on my web page, along with a tutorial and
more detailed explanation.


Brief Overview:

	Sound are Sine Waves. We can simulate sound waves with square waves,
which can be produced by rapidly turning on and shutting off the speakers.

                  ON
+5
              |----------|            |----------|                  
              |          |            |          |        
              |          |            |          |        
+0   _________|          |____________|          |________
                              OFF

	      |-----------------------|
                     Frequency

You turn on the speaker by turning on the link port wires, wait a delay,
and shut them off. Then you wait another delay, and shut it off. Make sure
the delays are equal.

You have sound!


Possible Future Projects:

	Interrupts - I am going to try to be able to produce sound through interrupts, maybe
I can achieve real time sound.

	Sound Library - It is a possibility, depending on how well I can improve this program.


----------
Matt Johnson
 matt2000@gte.net

ICQ: 8342478

http://www.dogtech.com/cybop/ti86/



